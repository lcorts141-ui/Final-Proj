from flask import Flask, request, jsonify, session, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from pathlib import Path
from datetime import datetime, date, timedelta
import sqlite3, base64, binascii, json, math, os, uuid

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "ice_n_bites.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("ICE_N_BITES_SECRET", "change-this-for-local-class-project")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
LOW_STOCK_DEFAULT = 5

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
          password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('Admin','Staff')),
          face_image_path TEXT NOT NULL, face_descriptor TEXT NOT NULL, id_image_path TEXT NOT NULL,
          id_status TEXT NOT NULL DEFAULT 'Pending', registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
          category TEXT NOT NULL, price REAL NOT NULL CHECK(price >= 0), active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS ingredients (
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
          quantity REAL NOT NULL DEFAULT 0, unit TEXT NOT NULL, reorder_level REAL NOT NULL DEFAULT 5,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS recipes (
          product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
          ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
          quantity REAL NOT NULL CHECK(quantity >= 0), PRIMARY KEY(product_id, ingredient_id)
        );
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL DEFAULT 'Walk-in Customer',
          total REAL NOT NULL, status TEXT NOT NULL DEFAULT 'Pending',
          payment_method TEXT NOT NULL DEFAULT 'Cash', stock_deducted INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS order_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
          product_id INTEGER REFERENCES products(id), product_name TEXT NOT NULL, category TEXT NOT NULL,
          quantity INTEGER NOT NULL, unit_price REAL NOT NULL, line_total REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        """)
        order_columns = [row["name"] for row in db.execute("PRAGMA table_info(orders)").fetchall()]
        if "stock_deducted" not in order_columns:
            db.execute("ALTER TABLE orders ADD COLUMN stock_deducted INTEGER NOT NULL DEFAULT 0")
        seeds = [
          ("Milk",20,"Liters",5),("Tapioca Pearls",4,"Kg",5),("Wintermelon Syrup",2,"Bottles",3),
          ("Tea Powder",5,"Kg",2),("Sugar",10,"Kg",3),("Coffee",4,"Kg",2),
          ("Fruit Syrup",6,"Bottles",2),("Cups",100,"Pieces",20),("Straws",100,"Pieces",20)
        ]
        for item in seeds:
            db.execute("INSERT OR IGNORE INTO ingredients(name,quantity,unit,reorder_level) VALUES(?,?,?,?)", item)
        menu_products = [('Okinawa Milk Tea (S)', 'Milk Tea', 30.0), ('Okinawa Milk Tea (M)', 'Milk Tea', 40.0), ('Okinawa Milk Tea (L)', 'Milk Tea', 50.0), ('Taro Milk Tea (S)', 'Milk Tea', 30.0), ('Taro Milk Tea (M)', 'Milk Tea', 40.0), ('Taro Milk Tea (L)', 'Milk Tea', 50.0), ('Caramel Milk Tea (S)', 'Milk Tea', 30.0), ('Salted Caramel Milk Tea (M)', 'Milk Tea', 40.0), ('Hazelnut Milk Tea (L)', 'Milk Tea', 50.0), ('Wintermelon Milk Tea (S)', 'Milk Tea', 30.0), ('Cookies n Cream Milk Tea (M)', 'Milk Tea', 40.0), ('Strawberry Milk Tea (L)', 'Milk Tea', 50.0), ('Matcha Milk', 'Milk Tea', 65.0), ('Macchiato Ice Coffee (M)', 'Coffee', 45.0), ('Macchiato Ice Coffee (L)', 'Coffee', 55.0), ('Hazelnut Ice Coffee (M)', 'Coffee', 45.0), ('Salted Caramel Ice Coffee (L)', 'Coffee', 55.0), ('Latte Ice Coffee (L)', 'Coffee', 55.0), ('Strawberry Fruitea (S)', 'Fruitea', 30.0), ('Strawberry Fruitea (M)', 'Fruitea', 40.0), ('Strawberry Fruitea (L)', 'Fruitea', 50.0), ('Lychee Fruitea (S)', 'Fruitea', 30.0), ('Honey Peach Fruitea (M)', 'Fruitea', 40.0), ('Blueberry Fruitea (L)', 'Fruitea', 50.0), ('Magical Soda (S)', 'Fruitea', 50.0), ('Magical Soda (M)', 'Fruitea', 60.0), ('Magical Soda (L)', 'Fruitea', 70.0), ('Soda Fizz (S)', 'Fruitea', 40.0), ('Soda Fizz (M)', 'Fruitea', 50.0), ('Soda Fizz (L)', 'Fruitea', 60.0), ('Fruity Yogurt (M)', 'Fruitea', 65.0), ('Fruity Milk (M)', 'Fruitea', 60.0), ('Lemon Series (M)', 'Fruitea', 45.0), ('Lemon Series (L)', 'Fruitea', 55.0), ('Chuckie Float (S)', 'Fruitea', 50.0), ('Chuckie Float (M)', 'Fruitea', 60.0), ('Coke Float (S)', 'Fruitea', 40.0), ('Coke Float (M)', 'Fruitea', 50.0), ('Coke Float (L)', 'Fruitea', 60.0), ('Fried Noodles (Plain)', 'Food', 40.0), ('Fried Noodles with Toppings', 'Food', 50.0), ('Burger', 'Food', 30.0), ('Cheese Burger', 'Food', 40.0), ('Burger Buy 1 Take 1', 'Food', 55.0), ('Cheese Burger Buy 1 Take 1', 'Food', 70.0), ('Flying Saucer - Cheese', 'Food', 20.0), ('Flying Saucer - Cheesy Ham', 'Food', 25.0), ('Flying Saucer - Burger', 'Food', 30.0), ('Flying Saucer - Cheese Burger', 'Food', 40.0), ('Pork Siomai (per piece)', 'Food', 5.0), ('Japanese Siomai (per piece)', 'Food', 6.0), ('French Fries - Cheese', 'Food', 25.0), ('French Fries - Sour n Cream', 'Food', 25.0), ('French Fries - Spicy BBQ', 'Food', 25.0), ('Takoyaki - Octobits', 'Food', 55.0), ('Takoyaki - Ham', 'Food', 50.0), ('Takoyaki - Octobits with Cheese', 'Food', 65.0), ('Takoyaki - Ham with Cheese', 'Food', 60.0), ('Mini Messy Donuts (3 pcs)', 'Food', 25.0), ('Mini Messy Donuts (6 pcs)', 'Food', 45.0), ('Mini Messy Donuts (8 pcs)', 'Food', 60.0), ('Mini Messy Donuts (10 pcs)', 'Food', 75.0), ('Mini Messy Donuts (20 pcs)', 'Food', 150.0)]
        for product in menu_products:
            db.execute('INSERT OR IGNORE INTO products(name,category,price) VALUES(?,?,?)', product)
        db.commit()

def error(message, status=400):
    return jsonify(error=message), status

def staff_required():
    return session.get("role") in ("Admin", "Staff")

def admin_required():
    return session.get("role") == "Admin"

def save_data_image(data_url, category):
    if not isinstance(data_url, str) or "," not in data_url: raise ValueError("Please provide a valid image.")
    header, encoded = data_url.split(",", 1)
    allowed = {"data:image/jpeg":".jpg","data:image/jpg":".jpg","data:image/png":".png","data:image/webp":".webp"}
    mime = header.split(";")[0].lower()
    if mime not in allowed: raise ValueError("Only JPG, PNG, or WEBP images are accepted.")
    try: image_bytes = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError): raise ValueError("The uploaded image is invalid.")
    if not image_bytes or len(image_bytes) > 5*1024*1024: raise ValueError("Each image must be smaller than 5 MB.")
    folder=UPLOAD_DIR/category; folder.mkdir(parents=True,exist_ok=True)
    filename=uuid.uuid4().hex+allowed[mime]; (folder/filename).write_bytes(image_bytes)
    return f"{category}/{filename}"

def safe_descriptor(value):
    return isinstance(value,list) and len(value)==128 and all(isinstance(x,(int,float)) and math.isfinite(x) for x in value)

@app.get("/")
def home(): return send_from_directory(BASE_DIR,"index.html")
@app.get("/auth")
@app.get("/auth.html")
def auth_page(): return send_from_directory(BASE_DIR,"auth.html")
@app.get("/<path:filename>")
def project_files(filename):
    target=(BASE_DIR/filename).resolve()
    if UPLOAD_DIR.resolve() in target.parents: abort(404)
    if not target.is_file() or BASE_DIR.resolve() not in target.parents: abort(404)
    return send_from_directory(BASE_DIR,filename)

@app.post("/api/register")
def register():
    data=request.get_json(silent=True) or {}
    username=str(data.get("username","")).strip(); password=str(data.get("password",""))
    role=data.get("role"); descriptor=data.get("face_descriptor")
    if len(username)<3 or len(username)>80: return error("Username must be 3 to 80 characters.")
    if len(password)<8: return error("Password must be at least 8 characters.")
    if role not in ("Admin","Staff"): return error("Please select a valid role.")
    if not safe_descriptor(descriptor): return error("Capture a valid facial picture before registering.")
    face_path=id_path=None
    try:
        face_path=save_data_image(data.get("face_image"),"faces")
        id_path=save_data_image(data.get("id_image"),"ids")
        with get_db() as db:
            db.execute("""INSERT INTO users(username,password_hash,role,face_image_path,face_descriptor,id_image_path,id_status)
              VALUES(?,?,?,?,?,?,'Pending')""",(username,generate_password_hash(password),role,face_path,json.dumps(descriptor),id_path))
            db.commit()
        return jsonify(message="Account saved successfully.",id_status="Pending"),201
    except sqlite3.IntegrityError: return error("That username already exists.",409)
    except ValueError as e: return error(str(e))
    except Exception:
        app.logger.exception("Registration failed"); return error("Registration could not be completed. Check the server terminal.",500)

@app.post("/api/login")
def login():
    data=request.get_json(silent=True) or {}; username=str(data.get("username","")).strip(); password=str(data.get("password",""))
    with get_db() as db: user=db.execute("SELECT * FROM users WHERE username=?",(username,)).fetchone()
    if not user or not check_password_hash(user["password_hash"],password): return error("Invalid username or password.",401)
    session.clear(); session.update(user_id=user["id"],username=user["username"],role=user["role"])
    return jsonify(message="Login successful.",username=user["username"],role=user["role"])

@app.post("/api/face-login")
def face_login():
    live=(request.get_json(silent=True) or {}).get("face_descriptor")
    if not safe_descriptor(live): return error("A valid face scan is required.")
    with get_db() as db: users=db.execute("SELECT id,username,role,face_descriptor FROM users").fetchall()
    matches=[]
    for user in users:
        try:
            saved=json.loads(user["face_descriptor"])
            if not safe_descriptor(saved): continue
            dist=math.sqrt(sum((float(a)-float(b))**2 for a,b in zip(live,saved)))
            matches.append((dist,user))
        except (ValueError,TypeError):
            continue
    matches.sort(key=lambda item: item[0])
    if not matches or matches[0][0] > 0.52:
        return error("Face not recognized. Improve the lighting or use your username and password.",401)
    # Reject close competing matches rather than choosing between two similar scores.
    if len(matches) > 1 and (matches[1][0] - matches[0][0]) < 0.04:
        return error("The face match is not sufficiently distinct. Please try again or use your password.",401)
    best=matches[0][1]
    session.clear(); session.update(user_id=best["id"],username=best["username"],role=best["role"])
    return jsonify(message="Face recognized.",username=best["username"],role=best["role"])

@app.get("/api/session")
def session_info(): return jsonify(logged_in=bool(session.get("user_id")),username=session.get("username"),role=session.get("role"))

@app.get("/api/records")
def records():
    if not admin_required(): return error("Please log in using an Admin account to view registration records.",403)
    with get_db() as db: rows=db.execute("SELECT id,username,role,id_status,registered_at FROM users ORDER BY registered_at DESC").fetchall()
    return jsonify(records=[{"id":r["id"],"username":r["username"],"role":r["role"],"face_image_url":f"/protected-image/{r['id']}/face","id_image_url":f"/protected-image/{r['id']}/id","id_status":r["id_status"],"registered_at":r["registered_at"]} for r in rows])

@app.post("/api/records/<int:user_id>/verify-id")
def verify_id(user_id):
    if not admin_required(): return error("Admin access required.",403)
    with get_db() as db:
        cur=db.execute("UPDATE users SET id_status='Verified' WHERE id=?",(user_id,)); db.commit()
    if not cur.rowcount: return error("User record not found.",404)
    return jsonify(message="ID marked as verified.")

@app.get("/protected-image/<int:user_id>/<kind>")
def protected_image(user_id,kind):
    if not admin_required(): abort(403)
    if kind not in ("face","id"): abort(404)
    col="face_image_path" if kind=="face" else "id_image_path"
    with get_db() as db: row=db.execute(f"SELECT {col} AS path FROM users WHERE id=?",(user_id,)).fetchone()
    if not row: abort(404)
    path=(UPLOAD_DIR/row["path"]).resolve()
    if UPLOAD_DIR.resolve() not in path.parents or not path.is_file(): abort(404)
    return send_from_directory(path.parent,path.name)

@app.get("/api/products")
def list_products():
    with get_db() as db: rows=db.execute("SELECT * FROM products WHERE active=1 ORDER BY category,name").fetchall()
    return jsonify(products=[dict(r) for r in rows])

@app.post("/api/products")
def save_product():
    if not staff_required(): return error("Staff or Admin login required.",403)
    d=request.get_json(silent=True) or {}; name=str(d.get("name","")).strip(); category=str(d.get("category","")).strip()
    try: price=float(d.get("price"))
    except (TypeError,ValueError): return error("Enter a valid product price.")
    if not name or not category or price<0: return error("Product name, category, and a valid price are required.")
    with get_db() as db:
        try:
            if d.get("id"):
                db.execute("UPDATE products SET name=?,category=?,price=?,active=1 WHERE id=?",(name,category,price,int(d["id"])))
            else: db.execute("INSERT INTO products(name,category,price) VALUES(?,?,?)",(name,category,price))
            db.commit()
        except sqlite3.IntegrityError: return error("A product with that name already exists.",409)
    return jsonify(message="Product saved.")

@app.delete("/api/products/<int:pid>")
def delete_product(pid):
    if not staff_required(): return error("Staff or Admin login required.",403)
    with get_db() as db: db.execute("UPDATE products SET active=0 WHERE id=?",(pid,)); db.commit()
    return jsonify(message="Product archived.")

@app.get("/api/ingredients")
def list_ingredients():
    if not staff_required(): return error("Staff or Admin login required.",403)
    with get_db() as db: rows=db.execute("SELECT * FROM ingredients ORDER BY name").fetchall()
    return jsonify(ingredients=[dict(r) for r in rows])

@app.post("/api/ingredients")
def save_ingredient():
    if not staff_required(): return error("Staff or Admin login required.",403)
    d=request.get_json(silent=True) or {}; name=str(d.get("name","")).strip(); unit=str(d.get("unit","")).strip()
    try: qty=float(d.get("quantity")); level=float(d.get("reorder_level",5))
    except (TypeError,ValueError): return error("Enter valid inventory quantities.")
    if not name or not unit or qty<0 or level<0: return error("Ingredient, unit, and non-negative quantities are required.")
    with get_db() as db:
        if d.get("id"): db.execute("UPDATE ingredients SET name=?,quantity=?,unit=?,reorder_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(name,qty,unit,level,int(d["id"])))
        else:
            try: db.execute("INSERT INTO ingredients(name,quantity,unit,reorder_level) VALUES(?,?,?,?)",(name,qty,unit,level))
            except sqlite3.IntegrityError: return error("Ingredient already exists.",409)
        db.commit()
    return jsonify(message="Inventory saved.")

@app.post("/api/recipes")
def save_recipe():
    if not staff_required(): return error("Staff or Admin login required.",403)
    d=request.get_json(silent=True) or {}
    try: pid=int(d["product_id"]); iid=int(d["ingredient_id"]); qty=float(d["quantity"])
    except (KeyError,TypeError,ValueError): return error("Choose a product, ingredient, and valid usage quantity.")
    if qty<=0: return error("Usage quantity must be greater than zero.")
    with get_db() as db:
        db.execute("INSERT INTO recipes(product_id,ingredient_id,quantity) VALUES(?,?,?) ON CONFLICT(product_id,ingredient_id) DO UPDATE SET quantity=excluded.quantity",(pid,iid,qty)); db.commit()
    return jsonify(message="Recipe usage saved.")

@app.get("/api/orders")
def list_orders():
    if not staff_required(): return error("Staff or Admin login required.",403)
    with get_db() as db:
        rows=db.execute("""SELECT o.*, GROUP_CONCAT(oi.quantity || ' x ' || oi.product_name, ', ') AS items
          FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id GROUP BY o.id ORDER BY o.id DESC LIMIT 100""").fetchall()
    return jsonify(orders=[dict(r) for r in rows])

@app.post("/api/orders")
def create_order():
    d=request.get_json(silent=True) or {}; items=d.get("items")
    if not isinstance(items,list) or not items: return error("Add at least one item to the order.")
    customer=str(d.get("customer_name") or "Walk-in Customer").strip()[:100]
    payment=str(d.get("payment_method") or "Cash")
    if payment not in ("Cash","GCash / Card"): payment="Cash"
    try:
        with get_db() as db:
            prepared=[]; total=0
            for item in items:
                name=str(item.get("name","")).strip(); category=str(item.get("category","")).strip()
                qty=int(item.get("qty",1)); price=float(item.get("price"))
                if not name or qty<1 or qty>100 or price<0: return error("An order item is invalid.")
                row=db.execute("SELECT id,price FROM products WHERE name=? AND active=1",(name,)).fetchone()
                if row: pid=row["id"]; price=float(row["price"])
                else:
                    cur=db.execute("INSERT INTO products(name,category,price) VALUES(?,?,?)",(name,category or "Other",price)); pid=cur.lastrowid
                line=qty*price; total+=line; prepared.append((pid,name,category or "Other",qty,price,line))
            cur=db.execute("INSERT INTO orders(customer_name,total,status,payment_method) VALUES(?,?, 'Pending',?)",(customer,total,payment))
            oid=cur.lastrowid
            for pid,name,category,qty,price,line in prepared:
                db.execute("INSERT INTO order_items(order_id,product_id,product_name,category,quantity,unit_price,line_total) VALUES(?,?,?,?,?,?,?)",(oid,pid,name,category,qty,price,line))
            db.commit()
        return jsonify(message="Order recorded successfully.",order_id=oid,total=total),201
    except Exception:
        app.logger.exception("Order creation failed"); return error("Could not save order. Please try again.",500)

@app.patch("/api/orders/<int:oid>")
def update_order(oid):
    if not staff_required(): return error("Staff or Admin login required.",403)
    status=(request.get_json(silent=True) or {}).get("status")
    if status not in ("Pending","Preparing","Completed","Cancelled"): return error("Invalid order status.")
    with get_db() as db:
        order=db.execute("SELECT status,stock_deducted FROM orders WHERE id=?",(oid,)).fetchone()
        if not order: return error("Order not found.",404)
        if status=="Completed" and not order["stock_deducted"]:
            items=db.execute("SELECT product_id,quantity FROM order_items WHERE order_id=?",(oid,)).fetchall()
            for item in items:
                if item["product_id"]:
                    recipes=db.execute("SELECT ingredient_id,quantity FROM recipes WHERE product_id=?",(item["product_id"],)).fetchall()
                    for recipe in recipes:
                        db.execute("UPDATE ingredients SET quantity=MAX(0,quantity-?),updated_at=CURRENT_TIMESTAMP WHERE id=?",(recipe["quantity"]*item["quantity"],recipe["ingredient_id"]))
        db.execute("UPDATE orders SET status=?,stock_deducted=CASE WHEN ?=? THEN 1 ELSE stock_deducted END WHERE id=?",(status,status,"Completed",oid)); db.commit()
    return jsonify(message="Order status updated.")

@app.get("/api/dashboard")
def dashboard_data():
    if not staff_required(): return error("Staff or Admin login required.",403)
    today=date.today().isoformat()
    with get_db() as db:
        sales=db.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='Completed' AND date(created_at)=?",(today,)).fetchone()[0]
        order_count=db.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
        product_count=db.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
        low=db.execute("SELECT COUNT(*) FROM ingredients WHERE quantity<=reorder_level").fetchone()[0]
        recent=db.execute("SELECT id,customer_name,total,status,created_at FROM orders ORDER BY id DESC LIMIT 5").fetchall()
    return jsonify(today_sales=sales,total_orders=order_count,total_products=product_count,low_stock=low,recent_orders=[dict(r) for r in recent])

@app.get("/api/reports")
def reports():
    if not staff_required(): return error("Staff or Admin login required.",403)
    period=request.args.get("period","daily")
    if period not in ("daily","weekly","monthly"): return error("Invalid report period.")
    now=date.today()
    if period=="daily": start=now.isoformat()
    elif period=="weekly": start=(now-timedelta(days=now.weekday())).isoformat()
    else: start=now.replace(day=1).isoformat()
    with get_db() as db:
        summary=db.execute("SELECT COUNT(*) AS orders,COALESCE(SUM(total),0) AS sales FROM orders WHERE status='Completed' AND date(created_at)>=?",(start,)).fetchone()
        best=db.execute("""SELECT oi.product_name,SUM(oi.quantity) AS quantity,SUM(oi.line_total) AS revenue
          FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='Completed' AND date(o.created_at)>=?
          GROUP BY oi.product_name ORDER BY quantity DESC LIMIT 5""",(start,)).fetchall()
    return jsonify(period=period,start_date=start,completed_orders=summary["orders"],sales=summary["sales"],best_sellers=[dict(r) for r in best])

@app.get("/api/notifications")
def notifications():
    if not staff_required(): return error("Staff or Admin login required.",403)
    with get_db() as db: rows=db.execute("SELECT id,name,quantity,unit,reorder_level FROM ingredients WHERE quantity<=reorder_level ORDER BY quantity").fetchall()
    return jsonify(notifications=[dict(r) for r in rows])

@app.post("/api/logout")
def logout(): session.clear(); return jsonify(message="Logged out.")

@app.errorhandler(413)
def too_large(_e): return error("Request is too large. Please use smaller image files.",413)

if __name__=="__main__":
    init_db()
    print("Ice N Bites running at http://127.0.0.1:5000/auth")
    app.run(debug=True)
