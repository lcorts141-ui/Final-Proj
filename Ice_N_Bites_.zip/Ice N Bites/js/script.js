let cart = [];

function addToCart(name, price) {
    cart.push({ name: name, price: price });
    displayCart();
}

function displayCart() {
    const cartBox = document.getElementById("cart");

    if (!cartBox) return;

    if (cart.length === 0) {
        cartBox.innerHTML = "No items in your order.";
        return;
    }

    let total = 0;

    let html = "";

    cart.forEach(function(item, index) {
        total += item.price;

        html += "<p>" +
                (index + 1) + ". " +
                item.name +
                " - ₱" +
                item.price +
                "</p>";
    });

    html += "<hr><p><strong>Total: ₱" + total + "</strong></p>";

    cartBox.innerHTML = html;
}

function placeOrder() {
    if (cart.length === 0) {
        alert("Please add an item first.");
        return;
    }

    alert("Order submitted successfully!");
    cart = [];
    displayCart();
}

function changeStatus(button) {
    const row = button.parentElement.parentElement;
    const status = row.querySelector(".badge");

    if (status.classList.contains("pending")) {
        status.className = "badge preparing";
        status.textContent = "Preparing";
        button.textContent = "Complete";
    } else {
        status.className = "badge completed";
        status.textContent = "Completed";
        button.remove();
    }
}

function addUser() {

    const name = prompt("Enter username:");

    if (name === null || name.trim() === "") {
        return;
    }

    const role = prompt(
        "Enter role:\nCustomer\nStaff\nManager\nAdministrator"
    );

    if (role === null || role.trim() === "") {
        return;
    }

    const table = document.getElementById("userTable");

    if (!table) return;

    const row = table.insertRow();

    row.innerHTML = `
        <td>${name}</td>
        <td>${role}</td>
        <td>
            <span class="badge completed">
                Active
            </span>
        </td>
        <td>
            <button onclick="removeUser(this)">
                Remove
            </button>
        </td>
    `;

    updateUserCount();
}


// REMOVE USER
function removeUser(button) {

    const confirmation = confirm(
        "Are you sure you want to remove this user?"
    );

    if (!confirmation) {
        return;
    }

    const row = button.closest("tr");

    row.remove();

    updateUserCount();
}


// UPDATE USER COUNT
function updateUserCount() {

    const table = document.getElementById("userTable");
    const counter = document.getElementById("totalUsers");

    if (!table || !counter) return;

    counter.textContent = table.rows.length;
}


// ADD PRODUCT
function addProduct() {

    const name = prompt("Enter product name:");

    if (!name) return;

    const category = prompt("Enter category:");

    if (!category) return;

    const price = prompt("Enter price:");

    if (!price) return;

    const stock = prompt("Enter stock quantity:");

    if (!stock) return;

    const table = document.getElementById("productTable");

    if (!table) return;

    const row = table.insertRow();

    let status = "Available";
    let statusClass = "completed";

    if (Number(stock) <= 5) {
        status = "Low Stock";
        statusClass = "pending";
    }

    row.innerHTML = `
        <td>${name}</td>
        <td>${category}</td>
        <td>₱${price}</td>
        <td>${stock}</td>
        <td>
            <span class="badge ${statusClass}">
                ${status}
            </span>
        </td>
    `;

    updateProductCount();
}


// UPDATE PRODUCT COUNT
function updateProductCount() {

    const table = document.getElementById("productTable");
    const counter = document.getElementById("totalProducts");

    if (!table || !counter) return;

    counter.textContent = table.rows.length;
}


// SAVE SYSTEM SETTINGS
function saveSettings() {

    const storeName =
        document.getElementById("storeName").value;

    const notification =
        document.getElementById("notification").value;

    const payment =
        document.getElementById("payment").value;

    alert(
        "Settings saved successfully!\n\n" +
        "Store: " + storeName + "\n" +
        "Notifications: " + notification + "\n" +
        "Payment: " + payment
    );
}



// Authentication: Flask + SQLite backend. Existing shop/dashboard functions above remain unchanged.
function switchAuthTab(tab) {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const loginTabBtn = document.getElementById('loginTabBtn');
    const signupTabBtn = document.getElementById('signupTabBtn');
    if (!loginForm || !signupForm) return;
    loginForm.classList.toggle('active', tab === 'login');
    signupForm.classList.toggle('active', tab === 'signup');
    if (loginTabBtn) loginTabBtn.classList.toggle('active', tab === 'login');
    if (signupTabBtn) signupTabBtn.classList.toggle('active', tab === 'signup');
    const message = document.getElementById('authMessage');
    if (message) message.textContent = '';
}

async function apiRequest(url, data, method = 'POST') {
    const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: method === 'GET' ? undefined : JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Request failed.');
    return result;
}

function readImageAsDataURL(file, maxWidth = 900, quality = 0.75) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = () => reject(new Error('Could not read the selected image.'));
        reader.onload = () => {
            const image = new Image();
            image.onerror = () => reject(new Error('Please select a valid image.'));
            image.onload = () => {
                const scale = Math.min(1, maxWidth / image.width);
                const canvas = document.createElement('canvas');
                canvas.width = Math.round(image.width * scale);
                canvas.height = Math.round(image.height * scale);
                canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            image.src = reader.result;
        };
        reader.readAsDataURL(file);
    });
}

function loadImageElement(dataUrl) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('Could not open the selected photo.'));
        image.src = dataUrl;
    });
}

let faceModelsLoading = null;

async function loadFaceModels() {
    if (!window.faceapi) {
        throw new Error('The facial recognition library could not be loaded. Check your internet connection and try again.');
    }
    // Load the models once per page instead of downloading/loading them for every scan.
    if (faceapi.nets.tinyFaceDetector.isLoaded &&
        faceapi.nets.faceLandmark68Net.isLoaded &&
        faceapi.nets.faceRecognitionNet.isLoaded) return;
    if (!faceModelsLoading) {
        const modelUrl = 'https://justadudewhohacks.github.io/face-api.js/models';
        faceModelsLoading = Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(modelUrl),
            faceapi.nets.faceLandmark68Net.loadFromUri(modelUrl),
            faceapi.nets.faceRecognitionNet.loadFromUri(modelUrl)
        ]).catch(error => {
            faceModelsLoading = null;
            throw error;
        });
    }
    await faceModelsLoading;
}

async function getFaceDescriptor(input) {
    await loadFaceModels();
    // Use a larger detector input and a confidence threshold to reduce weak detections.
    const detections = await faceapi.detectAllFaces(
        input,
        new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 })
    ).withFaceLandmarks().withFaceDescriptors();

    if (detections.length === 0) {
        throw new Error('No face was detected. Improve the lighting, face the camera, and try again.');
    }
    if (detections.length > 1) {
        throw new Error('More than one face was detected. Make sure only your face is visible.');
    }
    const face = detections[0];
    if (face.detection.box.width < 80 || face.detection.box.height < 80) {
        throw new Error('Your face is too far from the camera. Move closer and try again.');
    }
    return Array.from(face.descriptor);
}

function startCamera(video) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return Promise.reject(new Error('Camera requires localhost or HTTPS.'));
    }
    return navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
        .then(stream => { video.srcObject = stream; return video.play(); });
}
function stopCamera(video) {
    if (video && video.srcObject) {
        video.srcObject.getTracks().forEach(track => track.stop());
        video.srcObject = null;
    }
}
function captureVideoImage(video) {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas;
}
function goToRole(role) {
    window.location.href = (role === 'Admin' || role === 'Staff') ? '/admin.html' : '/index.html';
}

document.addEventListener('DOMContentLoaded', () => {
    const message = document.getElementById('authMessage');
    const showMessage = (text, type = 'error') => {
        if (!message) return;
        message.className = 'auth-msg ' + type;
        message.textContent = text;
    };
    const signupForm = document.getElementById('signupForm');
    const loginForm = document.getElementById('loginForm');
    const signupVideo = document.getElementById('signupFaceVideo');
    const idInput = document.getElementById('signupIdPicture');
    const idVideo = document.getElementById('signupIdVideo');
    const startIdCamera = document.getElementById('startIdCameraBtn');
    const captureIdBtn = document.getElementById('captureIdBtn');
    const signupFaceUpload = document.getElementById('signupFaceUpload');
    const faceLoginUpload = document.getElementById('faceLoginUpload');
    const verifyUploadedFaceBtn = document.getElementById('verifyUploadedFaceBtn');
    let capturedIdData = null;
    const startSignupCamera = document.getElementById('startSignupCameraBtn');
    const captureSignupFace = document.getElementById('captureSignupFaceBtn');
    let capturedFaceData = null;
    let capturedFaceDescriptor = null;

    if (startSignupCamera && signupVideo) startSignupCamera.addEventListener('click', async () => {
        try {
            await startCamera(signupVideo);
            captureSignupFace.disabled = false;
            showMessage('Camera ready. Position your face clearly.', 'success');
        } catch (error) { showMessage(error.message); }
    });

    // Allow registration with an uploaded face photo as an alternative to the camera.
    if (signupFaceUpload) signupFaceUpload.addEventListener('change', async () => {
        try {
            const file = signupFaceUpload.files[0];
            if (!file) return;
            const dataUrl = await readImageAsDataURL(file, 1000, 0.82);
            const image = await loadImageElement(dataUrl);
            const descriptor = await getFaceDescriptor(image);
            capturedFaceData = dataUrl;
            capturedFaceDescriptor = descriptor;
            const preview = document.getElementById('signupFacePreview');
            preview.src = dataUrl;
            preview.hidden = false;
            stopCamera(signupVideo);
            showMessage('Face photo read successfully. Complete registration.', 'success');
        } catch (error) {
            capturedFaceData = null;
            capturedFaceDescriptor = null;
            showMessage(error.message);
        }
    });

    if (startIdCamera && idVideo) startIdCamera.addEventListener('click', async () => {
        try {
            idVideo.hidden = false;
            await startCamera(idVideo);
            captureIdBtn.disabled = false;
            showMessage('ID camera ready. Place the whole ID inside the frame.', 'success');
        } catch (error) { showMessage(error.message); }
    });
    if (captureIdBtn && idVideo) captureIdBtn.addEventListener('click', () => {
        try {
            capturedIdData = captureVideoImage(idVideo).toDataURL('image/jpeg', 0.82);
            const preview = document.getElementById('signupIdPreview');
            preview.src = capturedIdData;
            preview.hidden = false;
            if (idInput) idInput.value = '';
            stopCamera(idVideo);
            idVideo.hidden = true;
            captureIdBtn.disabled = true;
            showMessage('ID photo captured. It will be saved for administrator review.', 'success');
        } catch (error) { showMessage(error.message); }
    });

    if (captureSignupFace && signupVideo) captureSignupFace.addEventListener('click', async () => {
        try {
            const canvas = captureVideoImage(signupVideo);
            capturedFaceData = canvas.toDataURL('image/jpeg', 0.72);
            const preview = document.getElementById('signupFacePreview');
            preview.src = capturedFaceData;
            preview.hidden = false;
            captureSignupFace.disabled = true;
            captureSignupFace.textContent = 'Processing Face...';
            capturedFaceDescriptor = await getFaceDescriptor(canvas);
            stopCamera(signupVideo);
            captureSignupFace.textContent = 'Facial Picture Captured ✓';
            showMessage('Facial picture captured. Complete the registration form.', 'success');
        } catch (error) {
            capturedFaceData = null;
            capturedFaceDescriptor = null;
            captureSignupFace.disabled = false;
            captureSignupFace.textContent = 'Capture Facial Picture';
            showMessage(error.message);
        }
    });

    if (idInput) idInput.addEventListener('change', async () => {
        const preview = document.getElementById('signupIdPreview');
        try {
            if (idInput.files[0]) {
                capturedIdData = null;
                preview.src = await readImageAsDataURL(idInput.files[0], 1000, 0.82);
                preview.hidden = false;
            }
        } catch (error) { showMessage(error.message); }
    });

    if (signupForm) signupForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (!capturedFaceData || !capturedFaceDescriptor) {
            showMessage('Capture your facial picture before signing up.'); return;
        }
        if ((!idInput || !idInput.files[0]) && !capturedIdData) {
            showMessage('Upload an ID picture or capture it using the camera.'); return;
        }
        try {
            const idImage = capturedIdData || await readImageAsDataURL(idInput.files[0], 1000, 0.82);
            const result = await apiRequest('/api/register', {
                username: document.getElementById('signupUsername').value.trim(),
                password: document.getElementById('signupPassword').value,
                role: document.getElementById('signupRole').value,
                face_image: capturedFaceData,
                face_descriptor: capturedFaceDescriptor,
                id_image: idImage
            });
            showMessage(result.message + ' Your ID is saved with status Pending verification.', 'success');
            stopCamera(signupVideo);
            signupForm.reset();
            document.getElementById('signupFacePreview').hidden = true;
            document.getElementById('signupIdPreview').hidden = true;
            capturedFaceData = null;
            capturedFaceDescriptor = null;
            capturedIdData = null;
            if (signupFaceUpload) signupFaceUpload.value = '';
            captureSignupFace.disabled = true;
            captureSignupFace.textContent = 'Capture Facial Picture';
            setTimeout(() => switchAuthTab('login'), 1400);
        } catch (error) { showMessage(error.message); }
    });

    if (loginForm) loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        try {
            const result = await apiRequest('/api/login', {
                username: document.getElementById('loginUsername').value.trim(),
                password: document.getElementById('loginPassword').value
            });
            showMessage('Login successful. Redirecting...', 'success');
            setTimeout(() => goToRole(result.role), 500);
        } catch (error) { showMessage(error.message); }
    });

    const faceLoginBtn = document.getElementById('faceLoginBtn');
    const facePanel = document.getElementById('faceLoginPanel');
    const faceVideo = document.getElementById('faceLoginVideo');
    const startFaceBtn = document.getElementById('startFaceLoginBtn');
    const verifyFaceBtn = document.getElementById('verifyFaceLoginBtn');
    if (faceLoginBtn && facePanel) faceLoginBtn.addEventListener('click', () => {
        facePanel.hidden = !facePanel.hidden;
        if (facePanel.hidden) stopCamera(faceVideo);
        else showMessage('Use the camera to verify against a registered face.');
    });
    if (startFaceBtn && faceVideo) startFaceBtn.addEventListener('click', async () => {
        try {
            await startCamera(faceVideo);
            verifyFaceBtn.disabled = false;
            showMessage('Camera ready. Look directly at the camera.', 'success');
        } catch (error) { showMessage(error.message); }
    });
    if (verifyFaceBtn && faceVideo) verifyFaceBtn.addEventListener('click', async () => {
        verifyFaceBtn.disabled = true;
        try {
            const descriptor = await getFaceDescriptor(captureVideoImage(faceVideo));
            const result = await apiRequest('/api/face-login', { face_descriptor: descriptor });
            stopCamera(faceVideo);
            showMessage('Face recognized. Welcome, ' + result.username + '!', 'success');
            setTimeout(() => goToRole(result.role), 600);
        } catch (error) { showMessage(error.message); }
        finally { verifyFaceBtn.disabled = false; }
    });

    if (verifyUploadedFaceBtn && faceLoginUpload) verifyUploadedFaceBtn.addEventListener('click', async () => {
        try {
            const file = faceLoginUpload.files[0];
            if (!file) throw new Error('Choose a face photo first.');
            const dataUrl = await readImageAsDataURL(file, 1000, 0.82);
            const image = await loadImageElement(dataUrl);
            const descriptor = await getFaceDescriptor(image);
            const result = await apiRequest('/api/face-login', { face_descriptor: descriptor });
            showMessage('Face recognized. Welcome, ' + result.username + '!', 'success');
            setTimeout(() => goToRole(result.role), 600);
        } catch (error) { showMessage(error.message); }
    });

    // Load stored account/ID records in the admin dashboard.
    const recordsTable = document.getElementById('registrationRecordsTable');
    if (recordsTable) {
        apiRequest('/api/records', {}, 'GET').then(result => {
            recordsTable.innerHTML = '';
            result.records.forEach(record => {
                const row = document.createElement('tr');
                const values = [
                    record.username, record.role, record.registered_at,
                    record.id_status
                ];
                values.forEach(value => {
                    const cell = document.createElement('td');
                    cell.textContent = value || '';
                    row.appendChild(cell);
                });
                const faceCell = document.createElement('td');
                const faceImg = document.createElement('img');
                faceImg.src = record.face_image_url;
                faceImg.alt = 'Registered facial picture';
                faceImg.width = 65;
                faceCell.appendChild(faceImg);
                row.appendChild(faceCell);

                const idCell = document.createElement('td');
                const idImg = document.createElement('img');
                idImg.src = record.id_image_url;
                idImg.alt = 'Uploaded identity document';
                idImg.width = 85;
                idCell.appendChild(idImg);
                row.appendChild(idCell);

                const actionCell = document.createElement('td');
                if (record.id_status !== 'Verified') {
                    const button = document.createElement('button');
                    button.textContent = 'Mark ID Verified';
                    button.addEventListener('click', async () => {
                        try {
                            await apiRequest('/api/records/' + record.id + '/verify-id', {});
                            loadRegistrationRecords();
                        } catch (error) { alert(error.message); }
                    });
                    actionCell.appendChild(button);
                } else {
                    actionCell.textContent = 'Verified';
                }
                row.appendChild(actionCell);
                recordsTable.appendChild(row);
            });
        }).catch(error => { recordsTable.innerHTML = '<tr><td colspan="7">' + error.message + '</td></tr>'; });
    }
    window.addEventListener('beforeunload', () => {
        stopCamera(signupVideo);
        stopCamera(faceVideo);
        stopCamera(idVideo);
    });
});

async function loadRegistrationRecords() {
    const table = document.getElementById('registrationRecordsTable');
    if (!table) return;
    try {
        const response = await fetch('/api/records', { credentials: 'same-origin' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Could not load records.');
        table.innerHTML = '';
        data.records.forEach(record => {
            const row = document.createElement('tr');
            [record.username, record.role, record.registered_at, record.id_status].forEach(value => {
                const cell = document.createElement('td');
                cell.textContent = value || '';
                row.appendChild(cell);
            });
            for (const imageUrl of [record.face_image_url, record.id_image_url]) {
                const cell = document.createElement('td');
                const img = document.createElement('img');
                img.src = imageUrl; img.width = 80; img.alt = 'Registration record image';
                cell.appendChild(img); row.appendChild(cell);
            }
            const action = document.createElement('td');
            if (record.id_status !== 'Verified') {
                const button = document.createElement('button');
                button.textContent = 'Mark ID Verified';
                button.onclick = async () => {
                    try {
                        await apiRequest('/api/records/' + record.id + '/verify-id', {});
                        loadRegistrationRecords();
                    } catch (e) { alert(e.message); }
                };
                action.appendChild(button);
            } else action.textContent = 'Verified';
            row.appendChild(action); table.appendChild(row);
        });
    } catch (error) {
        table.innerHTML = '';
        const row = table.insertRow();
        const cell = row.insertCell();
        cell.colSpan = 7;
        cell.textContent = error.message;
    }
}


async function logout() {
    try {
        await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
    } finally {
        window.location.href = '/auth';
    }
}


// Customer ordering experience: category navigation, product cards, and live cart.
const iceNProducts = {
 'Milk Tea': [
  {name:'Okinawa Milk Tea (S)',price:30,emoji:'🧋',desc:'Okinawa milk tea · Small'}, {name:'Okinawa Milk Tea (M)',price:40,emoji:'🧋',desc:'Okinawa milk tea · Medium'}, {name:'Okinawa Milk Tea (L)',price:50,emoji:'🧋',desc:'Okinawa milk tea · Large'},
  {name:'Taro Milk Tea (S)',price:30,emoji:'💜',desc:'Taro milk tea · Small'}, {name:'Taro Milk Tea (M)',price:40,emoji:'💜',desc:'Taro milk tea · Medium'}, {name:'Taro Milk Tea (L)',price:50,emoji:'💜',desc:'Taro milk tea · Large'},
  {name:'Caramel Milk Tea (S)',price:30,emoji:'🧋',desc:'Caramel milk tea · Small'}, {name:'Salted Caramel Milk Tea (M)',price:40,emoji:'🧋',desc:'Salted caramel milk tea · Medium'}, {name:'Hazelnut Milk Tea (L)',price:50,emoji:'🧋',desc:'Hazelnut milk tea · Large'},
  {name:'Wintermelon Milk Tea (S)',price:30,emoji:'🧋',desc:'Wintermelon milk tea · Small'}, {name:'Cookies n Cream Milk Tea (M)',price:40,emoji:'🍪',desc:'Cookies n cream · Medium'}, {name:'Strawberry Milk Tea (L)',price:50,emoji:'🍓',desc:'Strawberry milk tea · Large'},
  {name:'Matcha Milk',price:65,emoji:'🍵',desc:'Matcha milk drink · Medium'}
 ],
 'Coffee': [
  {name:'Macchiato Ice Coffee (M)',price:45,emoji:'🧊',desc:'Macchiato iced coffee · Medium'}, {name:'Macchiato Ice Coffee (L)',price:55,emoji:'🧊',desc:'Macchiato iced coffee · Large'},
  {name:'Hazelnut Ice Coffee (M)',price:45,emoji:'☕',desc:'Hazelnut iced coffee · Medium'}, {name:'Salted Caramel Ice Coffee (L)',price:55,emoji:'☕',desc:'Salted caramel iced coffee · Large'}, {name:'Latte Ice Coffee (L)',price:55,emoji:'🥤',desc:'Latte iced coffee · Large'}
 ],
 'Fruitea': [
  {name:'Strawberry Fruitea (S)',price:30,emoji:'🍓',desc:'Strawberry fruit tea · Small'}, {name:'Strawberry Fruitea (M)',price:40,emoji:'🍓',desc:'Strawberry fruit tea · Medium'}, {name:'Strawberry Fruitea (L)',price:50,emoji:'🍓',desc:'Strawberry fruit tea · Large'},
  {name:'Lychee Fruitea (S)',price:30,emoji:'🍹',desc:'Lychee fruit tea · Small'}, {name:'Honey Peach Fruitea (M)',price:40,emoji:'🍑',desc:'Honey peach fruit tea · Medium'}, {name:'Blueberry Fruitea (L)',price:50,emoji:'🫐',desc:'Blueberry fruit tea · Large'},
  {name:'Magical Soda (S)',price:50,emoji:'🥤',desc:'Magical soda · Small'}, {name:'Magical Soda (M)',price:60,emoji:'🥤',desc:'Magical soda · Medium'}, {name:'Magical Soda (L)',price:70,emoji:'🥤',desc:'Magical soda · Large'},
  {name:'Soda Fizz (S)',price:40,emoji:'🥤',desc:'Soda fizz · Small'}, {name:'Soda Fizz (M)',price:50,emoji:'🥤',desc:'Soda fizz · Medium'}, {name:'Soda Fizz (L)',price:60,emoji:'🥤',desc:'Soda fizz · Large'},
  {name:'Fruity Yogurt (M)',price:65,emoji:'🍓',desc:'Fruity yogurt drink · Medium'}, {name:'Fruity Milk (M)',price:60,emoji:'🥛',desc:'Fruity milk · Medium'},
  {name:'Lemon Series (M)',price:45,emoji:'🍋',desc:'Lemon series · Medium'}, {name:'Lemon Series (L)',price:55,emoji:'🍋',desc:'Lemon series · Large'},
  {name:'Chuckie Float (S)',price:50,emoji:'🥤',desc:'Chuckie float · Small'}, {name:'Chuckie Float (M)',price:60,emoji:'🥤',desc:'Chuckie float · Medium'},
  {name:'Coke Float (S)',price:40,emoji:'🥤',desc:'Coke float · Small'}, {name:'Coke Float (M)',price:50,emoji:'🥤',desc:'Coke float · Medium'}, {name:'Coke Float (L)',price:60,emoji:'🥤',desc:'Coke float · Large'}
 ],
 'Food': [
  {name:'Fried Noodles (Plain)',price:40,emoji:'🍜',desc:'Plain fried noodles'}, {name:'Fried Noodles with Toppings',price:50,emoji:'🍜',desc:'Fried noodles with toppings (price may vary)'},
  {name:'Burger',price:30,emoji:'🍔',desc:'Solo burger'}, {name:'Cheese Burger',price:40,emoji:'🍔',desc:'Solo cheeseburger'}, {name:'Burger Buy 1 Take 1',price:55,emoji:'🍔',desc:'Buy one, take one burger'}, {name:'Cheese Burger Buy 1 Take 1',price:70,emoji:'🍔',desc:'Buy one, take one cheeseburger'},
  {name:'Flying Saucer - Cheese',price:20,emoji:'🥪',desc:'Solo cheese flying saucer'}, {name:'Flying Saucer - Cheesy Ham',price:25,emoji:'🥪',desc:'Solo cheesy ham flying saucer'}, {name:'Flying Saucer - Burger',price:30,emoji:'🥪',desc:'Solo burger flying saucer'}, {name:'Flying Saucer - Cheese Burger',price:40,emoji:'🥪',desc:'Solo cheeseburger flying saucer'},
  {name:'Pork Siomai (per piece)',price:5,emoji:'🥟',desc:'Pork siomai · each'}, {name:'Japanese Siomai (per piece)',price:6,emoji:'🥟',desc:'Japanese siomai · each'},
  {name:'French Fries - Cheese',price:25,emoji:'🍟',desc:'Cheese flavored fries · listed price'}, {name:'French Fries - Sour n Cream',price:25,emoji:'🍟',desc:'Sour cream flavored fries · listed price'}, {name:'French Fries - Spicy BBQ',price:25,emoji:'🍟',desc:'Spicy BBQ flavored fries · listed price'},
  {name:'Takoyaki - Octobits',price:55,emoji:'🐙',desc:'Octobits takoyaki'}, {name:'Takoyaki - Ham',price:50,emoji:'🐙',desc:'Ham takoyaki'}, {name:'Takoyaki - Octobits with Cheese',price:65,emoji:'🐙',desc:'Octobits takoyaki with cheese'}, {name:'Takoyaki - Ham with Cheese',price:60,emoji:'🐙',desc:'Ham takoyaki with cheese'},
  {name:'Mini Messy Donuts (3 pcs)',price:25,emoji:'🍩',desc:'Choose chocolate, strawberry, or matcha syrup and toppings'}, {name:'Mini Messy Donuts (6 pcs)',price:45,emoji:'🍩',desc:'Choose syrup and toppings'}, {name:'Mini Messy Donuts (8 pcs)',price:60,emoji:'🍩',desc:'Choose syrup and toppings'}, {name:'Mini Messy Donuts (10 pcs)',price:75,emoji:'🍩',desc:'Choose syrup and toppings'}, {name:'Mini Messy Donuts (20 pcs)',price:150,emoji:'🍩',desc:'Choose syrup and toppings'}
 ]
};
let iceNCart = [];
function moneyPHP(value){return '₱'+Number(value).toFixed(2)}
function openOrdering(){setTimeout(()=>{const el=document.getElementById('order-app');if(el)el.scrollIntoView({behavior:'smooth'});},50);}
function showCategory(category,button){
 const list=document.getElementById('categoryProducts'); if(!list)return;
 document.querySelectorAll('.category-tab').forEach(tab=>tab.classList.toggle('active',tab.dataset.category===category));
 const titles={'Milk Tea':'Creamy, classic, and full of flavor.','Coffee':'Your cozy boost, hot or iced.','Fruitea':'Bright, fruity, and refreshing.','Food':'Tasty bites to complete your order.'};
 document.getElementById('categoryTitle').textContent=category;
 document.getElementById('categorySubtitle').textContent=titles[category]||'';
 document.getElementById('menuCount').textContent=(iceNProducts[category]||[]).length+' items';
 list.innerHTML=(iceNProducts[category]||[]).map((p,i)=>`<article class="order-product-card"><div class="product-emoji">${p.emoji}</div><h4>${p.name}</h4><p>${p.desc}</p><div class="product-bottom"><span class="product-price">${moneyPHP(p.price)}</span><button class="add-product-btn" onclick="addIceProduct('${category}',${i})">+ Add</button></div></article>`).join('');
}
function addIceProduct(category,index){const product=iceNProducts[category][index];const existing=iceNCart.find(item=>item.name===product.name);if(existing)existing.qty++;else iceNCart.push({...product,category,qty:1});renderIceCart();}
function changeIceQty(name,delta){const item=iceNCart.find(p=>p.name===name);if(!item)return;item.qty+=delta;if(item.qty<=0)iceNCart=iceNCart.filter(p=>p.name!==name);renderIceCart();}
function removeIceItem(name){iceNCart=iceNCart.filter(p=>p.name!==name);renderIceCart();}
function renderIceCart(){const cart=document.getElementById('orderCart');if(!cart)return;const count=iceNCart.reduce((sum,p)=>sum+p.qty,0);const total=iceNCart.reduce((sum,p)=>sum+p.price*p.qty,0);document.getElementById('cartCount').textContent=count+' '+(count===1?'item':'items');document.getElementById('orderTotal').textContent=moneyPHP(total);if(!iceNCart.length){cart.innerHTML='<p class="empty-cart">Your order is empty.<br><span>Add something delicious!</span></p>';return;}cart.innerHTML=iceNCart.map(p=>`<div class="cart-line"><div>${p.emoji} ${p.name}<small>${moneyPHP(p.price)} each</small></div><strong>${moneyPHP(p.price*p.qty)}</strong><div class="cart-line-controls"><button aria-label="Decrease ${p.name}" onclick="changeIceQty(${JSON.stringify(p.name)},-1)">−</button><span>${p.qty}</span><button aria-label="Increase ${p.name}" onclick="changeIceQty(${JSON.stringify(p.name)},1)">+</button><button class="remove-item" onclick="removeIceItem(${JSON.stringify(p.name)})">Remove</button></div></div>`).join('');}
async function checkoutOrder(){
 const message=document.getElementById('orderMessage');
 if(!iceNCart.length){message.textContent='Please add at least one item before reviewing your order.';return;}
 const total=iceNCart.reduce((sum,p)=>sum+p.price*p.qty,0);
 if(!confirm('Submit this order? Total: '+moneyPHP(total)))return;
 message.textContent='Saving your order...';
 try{
  const response=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',
   body:JSON.stringify({customer_name:'Walk-in Customer',payment_method:'Cash',items:iceNCart.map(p=>({name:p.name,category:p.category,price:p.price,qty:p.qty}))})});
  const result=await response.json();if(!response.ok)throw new Error(result.error||'Order could not be saved.');
  message.textContent='Thank you! Your order #'+result.order_id+' has been recorded. Total: '+moneyPHP(result.total)+'.';
  iceNCart=[];renderIceCart();
 }catch(error){message.textContent=error.message;}
}
async function syncMenuFromDatabase(){
 try{
  const response=await fetch('/api/products');if(!response.ok)return;
  const data=await response.json();
  const categories={'Milk Tea':[],'Coffee':[],'Fruitea':[],'Food':[]};
  data.products.forEach(p=>{
   const old=(iceNProducts[p.category]||[]).find(x=>x.name===p.name);
   if(!categories[p.category])categories[p.category]=[];
   categories[p.category].push({name:p.name,price:Number(p.price),category:p.category,emoji:old?.emoji||'🧋',desc:old?.desc||p.category+' from Ice N Bites'});
  });
  Object.keys(iceNProducts).forEach(k=>iceNProducts[k]=categories[k]||[]);
  const active=document.querySelector('.category-tab.active');
  showCategory(active?.dataset.category||'Milk Tea');
 }catch(error){console.warn('Using built-in menu because database menu could not be loaded.',error);}
}
document.addEventListener('DOMContentLoaded',()=>{if(document.getElementById('categoryProducts'))syncMenuFromDatabase();});
