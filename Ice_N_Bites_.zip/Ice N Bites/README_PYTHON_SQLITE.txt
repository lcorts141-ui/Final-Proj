ICE N BITES — MILK TEA ORDERING AND INVENTORY MANAGEMENT SYSTEM
Updated: November 4, 2026
Technology: Python Flask + SQLite + HTML/CSS/JavaScript

PROJECT SCOPE (based on the project proposal PDF)
- Centralized admin/staff dashboard for sales, products, orders, and inventory.
- Customer ordering for Milk Tea, Coffee, Fruitea, and Food.
- Product management and SQLite storage.
- Ingredient inventory with configurable reorder levels and low-stock notifications.
- Product-to-ingredient recipe/usage setup. When an order is marked Completed, configured ingredient quantities are deducted from inventory.
- Order and sales transaction records.
- Daily, weekly, and monthly completed-sales reports and best-selling products.
- The system supports the project's SDG 8 objective by organizing daily operations and helping the shop use resources more efficiently.

PROJECT FOLDER
Ice N Bites/
  app.py
  index.html
  auth.html
  register.html
  admin.html
  requirements.txt
  README_PYTHON_SQLITE.txt
  css/style.css
  js/script.js

SETUP (Windows / VS Code)
1. Extract the ZIP and open the "Ice N Bites" folder in VS Code.
2. Open Terminal > New Terminal.
3. Create and activate a virtual environment:
   py -m venv .venv
   .venv\Scripts\Activate.ps1
4. Install dependencies:
   python -m pip install -r requirements.txt
5. Start the application:
   python app.py
6. Open http://127.0.0.1:5000/auth
7. Register an Admin account first (choose Admin in the role field), then register Staff accounts as needed.
8. Log in. Admin/Staff users can open the management dashboard at http://127.0.0.1:5000/admin.html.
9. Customers can open http://127.0.0.1:5000/ and submit an order using the Take an Order section.

DATABASE AND RECORDS
- SQLite database: ice_n_bites.db (created automatically beside app.py).
- The initial 63 menu products across Milk Tea, Coffee, Fruitea, and Food are seeded into SQLite on first run.
- Ingredient starter records are created on first run. These are sample starting quantities; update them to the client's actual stock.
- Orders, order items, products, ingredients, recipe usage, and user accounts are stored in SQLite.
- Face and ID images are saved in uploads/faces and uploads/ids. The face descriptor and image paths are stored in SQLite.
- Existing database files are retained; the app adds the stock-deduction tracking column if it is missing.

ADMIN / STAFF WORKFLOW
1. Use Product Management to add products or archive products. Products are loaded from SQLite in the customer menu.
2. Update Ingredient Inventory with the actual ingredient quantity, unit, and reorder level.
3. In Product Ingredient Usage, configure the amount of each ingredient consumed by one product. The project proposal does not specify exact recipe quantities, so the owner must supply these values.
4. Customers submit orders from the storefront. The order is saved with Pending status.
5. Staff/Admin update the order to Preparing and then Completed. Configured ingredient usage is deducted when an order is first marked Completed.
6. Review Low-stock Notifications and Sales Reports. Reports include Completed orders only.
7. ID images and registration verification records are visible to Admin accounts only.

PROJECT TIMELINE (from the proposal PDF)
- Week 6 — Initial Testing: November 4, 2026
- Week 7 — Revision of Systems: November 11, 2026
- Week 8 — Final Testing with Client: November 18, 2026
- Week 9 — Submission: November 25, 2026

TESTING CHECKLIST FOR NOVEMBER 4 INITIAL TESTING
[ ] Register and log in with Admin and Staff accounts.
[ ] Confirm the menu shows the existing 63 products and categories.
[ ] Submit a customer order and confirm it appears in the dashboard.
[ ] Change an order status to Preparing and Completed.
[ ] Add an ingredient and update its quantity/reorder level.
[ ] Configure ingredient usage for a product and test stock deduction on completion.
[ ] Confirm low-stock notifications appear at/below the reorder level.
[ ] Check Daily, Weekly, and Monthly reports after completing test orders.
[ ] Restart the Flask app and confirm records remain in SQLite.

IMPORTANT NOTES / LIMITATIONS
- The PDF describes the required system features but does not provide exact ingredient recipes, reorder quantities, or payment gateway credentials. Starter stock values are sample values and recipe usage must be configured with the shop owner.
- The checkout records an order as a Cash order for this class/demo build. It does not process an actual GCash/card payment.
- ID status is a manual Admin review field. The app stores an ID photo but does not independently authenticate the document.
- Browser face matching is a classroom demonstration, not secure biometric authentication. Face-api.js model files are loaded from the internet.
- Camera access normally requires localhost or HTTPS.
- This is a local class project. Do not expose the Flask development server publicly. Biometric and ID images are sensitive personal data; obtain consent and restrict access.
